//
//  ExpandFunc.swift
//  expandTheNumber
//
//  Created by Lambda_School_Loaner_268 on 2/12/20.
//  Copyright © 2020 Lambda. All rights reserved.
//

import Foundation

func expandTheNumber(num: Int) {
    
    var answers: [Int] = []
    var baseTen = num % 10
    var base99 = (num - baseTen) % 100
    var base999 = (num - base99 - baseTen) % 1000
    let base9999 = (num - base999 - base99 - baseTen) % 1000
    
    if num > 999 {
        answers.append(base9999)
    } else if num > 99 {
        answers.append(base999)
    } else if num > 9 {
        answers.append(base99)
    } else {
        answers.append(baseTen)
    }
    
     print(answers)
}


