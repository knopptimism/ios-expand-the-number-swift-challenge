import UIKit

var str = "Hello, playground"
func expandTheNumber(num: Int) {
    
    var answers: [Int] = []
    var ones = num % 10
    var tens = (num - ones) % 100
    var hundreds = (num - tens - ones) % 1000
    let thousands = (num - hundreds - tens - ones) % 10000
    
    if num > 999 {
        answers.append(thousands)
    }
    if num > 99 {
        answers.append(hundreds)
    }
    if num > 9 {
        answers.append(tens)
    }
    answers.append(ones)

    
    print(answers)
}

expandTheNumber(num: 9125)
